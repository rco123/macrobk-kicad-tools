import time

print("=== Track Width Mode Test ===")

print("[1] custom routing width -> 0.40 mm")
try:
    print("actual =", pcb_set_routing_track_width(0.40), "mm")
except Exception as exc:
    print("ERROR:", exc)

time.sleep(0.5)

print("[2] overwrite custom routing width -> 0.75 mm")
try:
    print("actual =", pcb_set_routing_track_width(0.75), "mm")
except Exception as exc:
    print("ERROR:", exc)

time.sleep(0.5)

print("[3] restore NetClass / Rule width")
try:
    print("actual =", pcb_set_netclass_track_width(), "mm")
except Exception as exc:
    print("ERROR:", exc)

print("=== END ===")
