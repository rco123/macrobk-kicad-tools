# Track width helpers

## API

```python
pcb_set_selected_track_width(width_mm)
pcb_set_routing_track_width(width_mm)
pcb_set_netclass_track_width()
```

### `pcb_set_selected_track_width(width_mm)`

Changes only already-routed `PCB_TRACK` objects that are selected at call time.
`PCB_VIA` is excluded. Connected but unselected segments are not changed.
The return value is the number of selected segments whose width changed.

```python
pcb_set_selected_track_width(0.8)
```

### `pcb_set_routing_track_width(width_mm)`

Selects one arbitrary custom routing width without adding an entry to KiCad's
predefined Track Width list. Repeated calls overwrite the one custom value.
The custom choice remains active until another routing width is selected or
`pcb_set_netclass_track_width()` is called.

When KiCad's interactive router is already active, live testing has shown the
current route continues with the newly selected custom width. Existing committed
track segments are not rewritten by this helper.

```python
pcb_set_routing_track_width(0.4)
pcb_set_routing_track_width(0.75)
```

KiCad 9 uses one `UseCustomTrackViaSize` flag for both custom track and via
sizes. Before enabling it, MacroBK copies the currently effective via diameter
and drill into the custom via slots so changing only track width does not jump
the via geometry to an unrelated older custom value.

### `pcb_set_netclass_track_width()`

Leaves custom track/via-size mode and selects KiCad's track-width index 0,
meaning "use netclass width". Existing routed tracks are not modified.

```python
pcb_set_netclass_track_width()
```

Because KiCad 9 exposes one shared custom track/via flag, restoring netclass
track width also leaves custom via-size mode. The function returns the effective
current routing width in mm when KiCad exposes it.

## Suggested live test

```python
print("custom 0.40 =", pcb_set_routing_track_width(0.40))
print("custom 0.75 =", pcb_set_routing_track_width(0.75))
print("netclass    =", pcb_set_netclass_track_width())
```

Verify in PCB Editor that:

1. 0.40 mm becomes the active custom routing width and is not added to the
   predefined width list.
2. 0.75 mm replaces the previous custom value rather than adding another preset.
3. `pcb_set_netclass_track_width()` returns the router to netclass/rule width.
4. Existing already-routed tracks do not change during items 1-3.
